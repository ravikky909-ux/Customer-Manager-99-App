# Customer Manager 99

Professional Android customer follow-up app for **Allrounder99** and **Rajahuli99**.

## Fixed Login

- ID: `Allrounder99`
- Password: `Kris@3060`

## Included Features

- Professional teal, black and white UI
- 3-second animated brand opening with Allrounder99 and Rajahuli99 logos
- Full-fit combined Gamerush99/Allrounder99/Rajahuli99 app icon
- Very smooth right-left PageView swiping between Dashboard, Customers, Add, Follow-Ups and Settings
- Bottom navigation and swipe position remain synchronized
- Customer name, mobile, WhatsApp, language, source, priority and notes
- Clipboard number paste and bulk multi-number paste
- Duplicate number protection and Indian `+91` formatting
- Statuses: Not Messaged, Messaged, Reply Received, Interested, Follow-Up, Converted, Not Interested, Wrong Number and Do Not Contact
- Search and status filters
- Direct WhatsApp opening with editable message template
- Call, SMS and copy number buttons
- Follow-up date/time with Android local notification
- Customer history/timeline
- Recycle bin, restore and permanent delete
- Full JSON backup copy/restore through clipboard
- Optional Firebase Auth + Firestore cloud synchronization across phones
- Local offline data works even when Firebase is not configured

## Build APK on GitHub

1. Create a new GitHub repository.
2. Upload all files and folders from this ZIP.
3. Open **Actions**.
4. Select **Build Customer Manager 99 APK**.
5. Press **Run workflow**.
6. After completion, download the `Customer-Manager-99-APK` artifact.

## Activate Cross-Phone Cloud Sync

The app is already coded for Firebase Email/Password Authentication and Cloud Firestore. The same fixed app login is mapped to one Firebase account, so all devices use the same customer collection.

In Firebase Console:

1. Create a Firebase project.
2. Enable **Authentication > Email/Password**.
3. Create **Cloud Firestore**.
4. Publish the rules from `firebase.rules`.
5. Create an Android app with package name:
   `com.gamerush99.customermanager99`
6. Copy these Android/Firebase values into GitHub repository secrets:

| GitHub Secret | Firebase value |
|---|---|
| `FIREBASE_API_KEY` | API key |
| `FIREBASE_APP_ID` | App ID |
| `FIREBASE_MESSAGING_SENDER_ID` | Messaging sender ID |
| `FIREBASE_PROJECT_ID` | Project ID |
| `FIREBASE_STORAGE_BUCKET` | Storage bucket (optional) |

Run the workflow again. The new APK will show **Cloud Sync Connected** after login. The first phone automatically creates the Firebase login account; the next phone signs in to the same account and sees the same data.

## Important Files

- `lib/screens.dart` — complete UI, smooth swiping and working actions
- `lib/app_controller.dart` — login, customer actions, follow-up and status logic
- `lib/services.dart` — local storage, Firebase sync and notifications
- `.github/workflows/build-apk.yml` — one-click GitHub APK build
- `firebase.rules` — secure per-user Firestore rules
- `assets/branding/` — all supplied logos and full-fit app icon

## Notes

- WhatsApp must be installed for the native WhatsApp link; the app falls back to the web WhatsApp link when needed.
- Scheduled notifications can be affected by battery restrictions on some Android brands.
- The app has no fixed customer-count limit. Available phone/cloud storage determines practical capacity.
