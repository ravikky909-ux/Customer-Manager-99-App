from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
android = root / 'android'

# App label, permissions and scheduled notification receivers.
manifest = android / 'app/src/main/AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text()
    text = re.sub(r'android:label="[^"]*"', 'android:label="Customer Manager 99"', text, count=1)
    permissions = (
        '    <uses-permission android:name="android.permission.INTERNET" />\n'
        '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n'
    )
    if 'android.permission.INTERNET' not in text:
        text = text.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
                            '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n' + permissions)
    receivers = '''
        <receiver
            android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver
            android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
'''
    if 'ScheduledNotificationReceiver' not in text:
        text = text.replace('</application>', receivers + '    </application>')
    manifest.write_text(text)

# Kotlin Gradle template used by current Flutter.
kts = android / 'app/build.gradle.kts'
if kts.exists():
    text = kts.read_text()
    text = re.sub(r'compileSdk\s*=\s*flutter\.compileSdkVersion', 'compileSdk = 36', text)
    text = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23', text)
    if 'isCoreLibraryDesugaringEnabled' not in text:
        text = text.replace('compileOptions {',
            'compileOptions {\n        isCoreLibraryDesugaringEnabled = true')
    if 'multiDexEnabled = true' not in text:
        text = text.replace('defaultConfig {', 'defaultConfig {\n        multiDexEnabled = true')
    if 'coreLibraryDesugaring(' not in text:
        text += '\n\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    kts.write_text(text)

# Groovy template fallback.
groovy = android / 'app/build.gradle'
if groovy.exists():
    text = groovy.read_text()
    text = re.sub(r'compileSdkVersion\s+flutter\.compileSdkVersion', 'compileSdkVersion 36', text)
    text = re.sub(r'minSdkVersion\s+flutter\.minSdkVersion', 'minSdkVersion 23', text)
    if 'coreLibraryDesugaringEnabled true' not in text:
        text = text.replace('compileOptions {',
            'compileOptions {\n        coreLibraryDesugaringEnabled true')
    if 'multiDexEnabled true' not in text:
        text = text.replace('defaultConfig {', 'defaultConfig {\n        multiDexEnabled true')
    if 'coreLibraryDesugaring ' not in text:
        text += "\n\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    groovy.write_text(text)

# AGP requirement for flutter_local_notifications 22.x.
for settings_name in ('settings.gradle.kts', 'settings.gradle'):
    settings = android / settings_name
    if not settings.exists():
        continue
    text = settings.read_text()
    if settings_name.endswith('.kts'):
        text = re.sub(
            r'id\("com\.android\.application"\) version "[^"]+" apply false',
            'id("com.android.application") version "8.11.1" apply false',
            text,
        )
    else:
        text = re.sub(
            r"id 'com\.android\.application' version '[^']+' apply false",
            "id 'com.android.application' version '8.11.1' apply false",
            text,
        )
    settings.write_text(text)

# Force package/application id.
for build_file in (kts, groovy):
    if not build_file.exists():
        continue
    text = build_file.read_text()
    if build_file.suffix == '.kts':
        text = re.sub(r'namespace\s*=\s*"[^"]+"', 'namespace = "com.gamerush99.customermanager99"', text)
        text = re.sub(r'applicationId\s*=\s*"[^"]+"', 'applicationId = "com.gamerush99.customermanager99"', text)
    else:
        text = re.sub(r'namespace\s+"[^"]+"', 'namespace "com.gamerush99.customermanager99"', text)
        text = re.sub(r'applicationId\s+"[^"]+"', 'applicationId "com.gamerush99.customermanager99"', text)
    build_file.write_text(text)


# Align MainActivity package with the final application namespace.
for activity in (android / 'app/src/main').rglob('MainActivity.kt'):
    text = activity.read_text()
    text = re.sub(r'^package\s+[^\n]+', 'package com.gamerush99.customermanager99', text, flags=re.MULTILINE)
    activity.write_text(text)
for activity in (android / 'app/src/main').rglob('MainActivity.java'):
    text = activity.read_text()
    text = re.sub(r'^package\s+[^;]+;', 'package com.gamerush99.customermanager99;', text, flags=re.MULTILINE)
    activity.write_text(text)

print('Android project prepared.')
