import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import 'app_controller.dart';
import 'app_scope.dart';
import 'models.dart';
import 'services.dart';

const Color appTeal = Color(0xFF008E98);
const Color appDark = Color(0xFF071318);
const Color appGold = Color(0xFFFFB625);

Color statusColor(String status) {
  switch (status) {
    case 'Messaged':
      return const Color(0xFF2EAD62);
    case 'Reply Received':
      return const Color(0xFF1769D2);
    case 'Interested':
      return const Color(0xFF6658D9);
    case 'Follow-Up':
      return const Color(0xFF8E44AD);
    case 'Converted':
      return const Color(0xFF087F5B);
    case 'Not Interested':
      return const Color(0xFF7C7C7C);
    case 'Wrong Number':
      return const Color(0xFFE24A4A);
    case 'Do Not Contact':
      return const Color(0xFF111827);
    default:
      return const Color(0xFFF29A2E);
  }
}

String displayPhone(String value) {
  final String digits = normalizePhone(value);
  if (digits.length == 12 && digits.startsWith('91')) {
    return '+91 ${digits.substring(2, 7)} ${digits.substring(7)}';
  }
  return value;
}

String formatDateTime(DateTime? value) {
  if (value == null) return 'Not set';
  return DateFormat('dd MMM yyyy, hh:mm a').format(value);
}

void showAppSnack(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? Colors.red.shade700 : appDark,
        behavior: SnackBarBehavior.floating,
      ),
    );
}

Future<void> openWhatsApp(
  BuildContext context,
  Customer customer,
) async {
  final AppController controller = AppScope.of(context);
  final String number = normalizePhone(
    customer.whatsapp.isEmpty ? customer.mobile : customer.whatsapp,
  );
  final String message = controller.personalizedMessage(customer);
  final Uri native = Uri.parse(
    'whatsapp://send?phone=$number&text=${Uri.encodeComponent(message)}',
  );
  final Uri web = Uri.parse(
    'https://wa.me/$number?text=${Uri.encodeComponent(message)}',
  );

  bool launched = false;
  try {
    launched = await launchUrl(native, mode: LaunchMode.externalApplication);
  } catch (_) {
    launched = false;
  }
  if (!launched) {
    try {
      launched = await launchUrl(web, mode: LaunchMode.externalApplication);
    } catch (_) {
      launched = false;
    }
  }
  if (launched) {
    await controller.markWhatsAppOpened(customer);
  } else if (context.mounted) {
    showAppSnack(context, 'WhatsApp open nahi hua.', error: true);
  }
}

Future<void> openDialer(BuildContext context, Customer customer) async {
  final Uri uri = Uri(scheme: 'tel', path: customer.mobile);
  if (!await launchUrl(uri, mode: LaunchMode.externalApplication) &&
      context.mounted) {
    showAppSnack(context, 'Dialer open nahi hua.', error: true);
  }
}

Future<void> openSms(BuildContext context, Customer customer) async {
  final Uri uri = Uri(
    scheme: 'sms',
    path: customer.mobile,
    queryParameters: <String, String>{
      'body': AppScope.of(context).personalizedMessage(customer),
    },
  );
  if (!await launchUrl(uri, mode: LaunchMode.externalApplication) &&
      context.mounted) {
    showAppSnack(context, 'SMS app open nahi hua.', error: true);
  }
}

Future<DateTime?> pickFollowUpDateTime(
  BuildContext context, {
  DateTime? initial,
}) async {
  final DateTime now = DateTime.now();
  final DateTime start = initial != null && initial.isAfter(now)
      ? initial
      : now.add(const Duration(hours: 1));
  final DateTime? date = await showDatePicker(
    context: context,
    firstDate: DateTime(now.year, now.month, now.day),
    lastDate: DateTime(now.year + 5),
    initialDate: start,
  );
  if (date == null || !context.mounted) return null;
  final TimeOfDay? time = await showTimePicker(
    context: context,
    initialTime: TimeOfDay.fromDateTime(start),
  );
  if (time == null) return null;
  return DateTime(date.year, date.month, date.day, time.hour, time.minute);
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _logoScale;
  late final Animation<double> _fade;
  late final Animation<Offset> _leftSlide;
  late final Animation<Offset> _rightSlide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..forward();
    _logoScale = Tween<double>(begin: 0.72, end: 1).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0, 0.55, curve: Curves.easeOutBack),
      ),
    );
    _fade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0, 0.8, curve: Curves.easeIn),
    );
    _leftSlide = Tween<Offset>(
      begin: const Offset(-1.2, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.35, 0.86, curve: Curves.easeOutCubic),
    ));
    _rightSlide = Tween<Offset>(
      begin: const Offset(1.2, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.35, 0.86, curve: Curves.easeOutCubic),
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appDark,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: <Color>[
                  Color(0xFF0B5260),
                  Color(0xFF081A20),
                  Color(0xFF030708),
                ],
              ),
            ),
          ),
          SafeArea(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (BuildContext context, Widget? child) {
                return Column(
                  children: <Widget>[
                    const Spacer(),
                    FadeTransition(
                      opacity: _fade,
                      child: ScaleTransition(
                        scale: _logoScale,
                        child: Container(
                          width: 220,
                          height: 220,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: appGold, width: 2),
                            boxShadow: const <BoxShadow>[
                              BoxShadow(
                                color: Color(0x8869F4FF),
                                blurRadius: 36,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              'assets/branding/combined_brand.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 26),
                    const Text(
                      'CUSTOMER MANAGER 99',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: SlideTransition(
                              position: _leftSlide,
                              child: _SplashLogoCard(
                                image: 'assets/branding/allrounder99.png',
                                label: 'ALLROUNDER99',
                                accent: Colors.cyanAccent,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: SlideTransition(
                              position: _rightSlide,
                              child: _SplashLogoCard(
                                image: 'assets/branding/rajahuli99.jpg',
                                label: 'RAJAHULI99',
                                accent: appGold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    FadeTransition(
                      opacity: _fade,
                      child: const Text(
                        'Secure • Smart • Synced',
                        style: TextStyle(color: Colors.white70),
                      ),
                    ),
                    const SizedBox(height: 30),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _SplashLogoCard extends StatelessWidget {
  const _SplashLogoCard({
    required this.image,
    required this.label,
    required this.accent,
  });

  final String image;
  final String label;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 118,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: accent.withOpacity(0.8)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: accent.withOpacity(0.25), blurRadius: 22),
        ],
      ),
      child: Column(
        children: <Widget>[
          Expanded(child: Image.asset(image, fit: BoxFit.contain)),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: appDark,
              fontWeight: FontWeight.w900,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _id = TextEditingController(text: 'Allrounder99');
  final TextEditingController _password = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _id.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    final AppController controller = AppScope.of(context);
    final LoginResult result = await controller.login(_id.text, _password.text);
    if (!mounted) return;
    showAppSnack(context, result.message, error: !result.success);
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[Color(0xFF004E58), appDark],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: const <BoxShadow>[
                      BoxShadow(color: Colors.black38, blurRadius: 30),
                    ],
                  ),
                  child: Column(
                    children: <Widget>[
                      ClipOval(
                        child: Image.asset(
                          'assets/branding/app_icon_safe.png',
                          width: 112,
                          height: 112,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'Customer Manager 99',
                        style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w900,
                          color: appDark,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'Allrounder99 & Rajahuli99',
                        style: TextStyle(color: Colors.black54),
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        controller: _id,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'Login ID',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextField(
                        controller: _password,
                        obscureText: _obscure,
                        onSubmitted: (_) => _submit(),
                        decoration: InputDecoration(
                          labelText: 'Password',
                          prefixIcon: const Icon(Icons.lock_outline),
                          suffixIcon: IconButton(
                            onPressed: () =>
                                setState(() => _obscure = !_obscure),
                            icon: Icon(
                              _obscure
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: FilledButton.icon(
                          onPressed: controller.loginBusy ? null : _submit,
                          icon: controller.loginBusy
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.login_rounded),
                          label: Text(
                            controller.loginBusy ? 'Connecting...' : 'LOGIN',
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      const Text(
                        'Same ID se dusre phone me login karne par cloud data sync hoga.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShellScreen extends StatefulWidget {
  const MainShellScreen({super.key});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  late final PageController _pageController;
  AppController? _controller;
  int _visibleIndex = 0;
  bool _programmaticMove = false;
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    _controller = AppScope.of(context);
    _visibleIndex = _controller!.pageIndex;
    _pageController = PageController(initialPage: _visibleIndex);
    _controller!.addListener(_syncExternalPage);
    _initialized = true;
  }

  void _syncExternalPage() {
    final AppController? controller = _controller;
    if (!mounted || controller == null || _programmaticMove ||
        controller.pageIndex == _visibleIndex ||
        !_pageController.hasClients) {
      return;
    }
    _programmaticMove = true;
    _pageController
        .animateToPage(
          controller.pageIndex,
          duration: const Duration(milliseconds: 360),
          curve: Curves.easeOutCubic,
        )
        .whenComplete(() => _programmaticMove = false);
  }

  @override
  void dispose() {
    _controller?.removeListener(_syncExternalPage);
    if (_initialized) _pageController.dispose();
    super.dispose();
  }

  void _goTo(int index) {
    _programmaticMove = true;
    (_controller ?? AppScope.of(context)).setPage(index);
    if (!_pageController.hasClients) {
      _programmaticMove = false;
      return;
    }
    _pageController
        .animateToPage(
          index,
          duration: const Duration(milliseconds: 360),
          curve: Curves.easeOutCubic,
        )
        .whenComplete(() => _programmaticMove = false);
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<Widget> pages = <Widget>[
      DashboardPage(onOpenCustomers: (String filter) {
        controller.setCustomerFilter(filter);
        _goTo(1);
      }),
      const CustomersPage(),
      CustomerFormPage(
        onSaved: () {
          controller.setCustomerFilter('All');
          _goTo(1);
        },
      ),
      const FollowUpsPage(),
      const SettingsPage(),
    ];

    return Scaffold(
      body: PageView(
        controller: _pageController,
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        allowImplicitScrolling: true,
        onPageChanged: (int index) {
          setState(() => _visibleIndex = index);
          if (!_programmaticMove) controller.setPage(index);
        },
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _visibleIndex,
        onDestinationSelected: _goTo,
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard_rounded),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people),
            label: 'Customers',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_add_alt_1_outlined),
            selectedIcon: Icon(Icons.person_add_alt_1),
            label: 'Add',
          ),
          NavigationDestination(
            icon: Icon(Icons.notifications_none),
            selectedIcon: Icon(Icons.notifications_active),
            label: 'Follow-Ups',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({required this.onOpenCustomers, super.key});

  final ValueChanged<String> onOpenCustomers;

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<Customer> customers = controller.customers;
    final DateTime now = DateTime.now();
    final DateTime today = DateTime(now.year, now.month, now.day);

    int countStatus(String value) =>
        customers.where((Customer c) => c.status == value).length;
    final int followToday = customers.where((Customer c) {
      final DateTime? follow = c.followUpAt;
      if (follow == null) return false;
      final DateTime day = DateTime(follow.year, follow.month, follow.day);
      return day == today;
    }).length;
    final int addedToday = customers.where((Customer c) {
      final DateTime day =
          DateTime(c.createdAt.year, c.createdAt.month, c.createdAt.day);
      return day == today;
    }).length;

    final List<_DashboardStat> stats = <_DashboardStat>[
      _DashboardStat('Total Customers', customers.length, Icons.people, 'All'),
      _DashboardStat(
        'Not Messaged',
        countStatus('Not Messaged'),
        Icons.mark_chat_unread_outlined,
        'Not Messaged',
      ),
      _DashboardStat(
        'Messaged',
        countStatus('Messaged'),
        Icons.chat_rounded,
        'Messaged',
      ),
      _DashboardStat(
        'Interested',
        countStatus('Interested'),
        Icons.star_rounded,
        'Interested',
      ),
      _DashboardStat(
        'Follow-Up Today',
        followToday,
        Icons.calendar_month_rounded,
        'Follow-Up',
      ),
      _DashboardStat(
        'Converted',
        countStatus('Converted'),
        Icons.verified_rounded,
        'Converted',
      ),
      _DashboardStat(
        'Wrong Numbers',
        countStatus('Wrong Number'),
        Icons.phone_disabled_rounded,
        'Wrong Number',
      ),
      _DashboardStat(
        'Added Today',
        addedToday,
        Icons.person_add_alt_1_rounded,
        'All',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Customer Manager 99',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Tooltip(
              message: controller.cloudConnected
                  ? 'Cloud sync connected'
                  : 'Local mode',
              child: Icon(
                controller.cloudConnected
                    ? Icons.cloud_done_rounded
                    : Icons.cloud_off_rounded,
              ),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => Future<void>.delayed(
          const Duration(milliseconds: 450),
        ),
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: <Color>[Color(0xFF053B43), appTeal],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          DateFormat('EEEE, dd MMM').format(now),
                          style: const TextStyle(color: Colors.white70),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Good day, Admin!',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 23,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          controller.cloudConnected
                              ? 'Data live cloud me sync ho raha hai.'
                              : 'Local mode active. Firebase config ke baad cross-phone sync hoga.',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  ClipOval(
                    child: Image.asset(
                      'assets/branding/app_icon_safe.png',
                      width: 74,
                      height: 74,
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: stats.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.25,
              ),
              itemBuilder: (BuildContext context, int index) {
                final _DashboardStat stat = stats[index];
                return InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => onOpenCustomers(stat.filter),
                  child: Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFE0EAEC)),
                      boxShadow: const <BoxShadow>[
                        BoxShadow(
                          color: Color(0x0D000000),
                          blurRadius: 14,
                          offset: Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: appTeal.withOpacity(0.12),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(stat.icon, color: appTeal),
                        ),
                        const Spacer(),
                        Text(
                          '${stat.value}',
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: appDark,
                          ),
                        ),
                        Text(
                          stat.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 18),
            Row(
              children: <Widget>[
                Expanded(
                  child: _BrandMiniCard(
                    image: 'assets/branding/allrounder99.png',
                    title: 'Allrounder99',
                    accent: Colors.cyan,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _BrandMiniCard(
                    image: 'assets/branding/rajahuli99.jpg',
                    title: 'Rajahuli99',
                    accent: Colors.orange,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _DashboardStat {
  const _DashboardStat(this.title, this.value, this.icon, this.filter);
  final String title;
  final int value;
  final IconData icon;
  final String filter;
}

class _BrandMiniCard extends StatelessWidget {
  const _BrandMiniCard({
    required this.image,
    required this.title,
    required this.accent,
  });

  final String image;
  final String title;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 112,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: accent.withOpacity(0.35)),
      ),
      child: Column(
        children: <Widget>[
          Expanded(child: Image.asset(image, fit: BoxFit.contain)),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});

  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage>
    with AutomaticKeepAliveClientMixin {
  final TextEditingController _search = TextEditingController();

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppController controller = AppScope.of(context);
    final String query = _search.text.trim().toLowerCase();
    final String filter = controller.customerFilter;
    final List<Customer> filtered = controller.customers.where((Customer c) {
      final bool statusMatches = filter == 'All' || c.status == filter;
      final bool queryMatches = query.isEmpty ||
          c.name.toLowerCase().contains(query) ||
          c.mobile.contains(query) ||
          c.whatsapp.contains(query) ||
          c.source.toLowerCase().contains(query);
      return statusMatches && queryMatches;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Customers (${filtered.length})',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: <Widget>[
          IconButton(
            tooltip: 'Paste number',
            onPressed: () async {
              final ClipboardData? data =
                  await Clipboard.getData(Clipboard.kTextPlain);
              if (!context.mounted) return;
              final String raw = data?.text ?? '';
              if (raw.trim().isEmpty) {
                showAppSnack(context, 'Clipboard empty hai.', error: true);
                return;
              }
              final int added = await controller.importMultipleNumbers(raw);
              if (context.mounted) {
                showAppSnack(context, '$added new number save hue.');
              }
            },
            icon: const Icon(Icons.content_paste_go_rounded),
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Name ya number search karo...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _search.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.close),
                      ),
              ),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: <String>['All', ...customerStatuses]
                  .map((String status) => Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          selected: filter == status,
                          label: Text(status),
                          onSelected: (_) =>
                              controller.setCustomerFilter(status),
                        ),
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: filtered.isEmpty
                ? const _EmptyState(
                    icon: Icons.people_outline,
                    title: 'Customer nahi mila',
                    subtitle: 'Add page se new customer save karo.',
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 22),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (BuildContext context, int index) {
                      return CustomerCard(customer: filtered[index]);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class CustomerCard extends StatelessWidget {
  const CustomerCard({required this.customer, super.key});
  final Customer customer;

  @override
  Widget build(BuildContext context) {
    final Color chipColor = statusColor(customer.status);
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => CustomerDetailPage(customerId: customer.id),
          ),
        ),
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE2EBED)),
          ),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: chipColor.withOpacity(0.14),
                    child: Text(
                      customer.name.trim().isEmpty
                          ? '?'
                          : customer.name.trim()[0].toUpperCase(),
                      style: TextStyle(
                        color: chipColor,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          customer.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          displayPhone(customer.mobile),
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(
                      color: chipColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      customer.status,
                      style: TextStyle(
                        color: chipColor,
                        fontWeight: FontWeight.w800,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  _QuickAction(
                    icon: Icons.copy_rounded,
                    tooltip: 'Copy number',
                    onTap: () async {
                      await Clipboard.setData(
                        ClipboardData(text: customer.mobile),
                      );
                      if (context.mounted) {
                        showAppSnack(context, 'Number copied.');
                      }
                    },
                  ),
                  _QuickAction(
                    icon: Icons.chat_rounded,
                    color: const Color(0xFF16A34A),
                    tooltip: 'WhatsApp',
                    onTap: () => openWhatsApp(context, customer),
                  ),
                  _QuickAction(
                    icon: Icons.call_rounded,
                    color: appTeal,
                    tooltip: 'Call',
                    onTap: () => openDialer(context, customer),
                  ),
                  _QuickAction(
                    icon: Icons.sms_outlined,
                    color: Colors.indigo,
                    tooltip: 'SMS',
                    onTap: () => openSms(context, customer),
                  ),
                  _QuickAction(
                    icon: Icons.arrow_forward_ios_rounded,
                    tooltip: 'Details',
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) =>
                            CustomerDetailPage(customerId: customer.id),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.color = Colors.black54,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      visualDensity: VisualDensity.compact,
      tooltip: tooltip,
      onPressed: onTap,
      icon: Icon(icon, color: color, size: 21),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 72, color: appTeal.withOpacity(0.45)),
            const SizedBox(height: 14),
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomerFormPage extends StatefulWidget {
  const CustomerFormPage({this.existing, this.onSaved, super.key});

  final Customer? existing;
  final VoidCallback? onSaved;

  @override
  State<CustomerFormPage> createState() => _CustomerFormPageState();
}

class _CustomerFormPageState extends State<CustomerFormPage>
    with AutomaticKeepAliveClientMixin {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _mobile;
  late final TextEditingController _whatsapp;
  late final TextEditingController _notes;
  late String _language;
  late String _source;
  late String _priority;
  bool _saving = false;

  @override
  bool get wantKeepAlive => widget.existing == null;

  @override
  void initState() {
    super.initState();
    final Customer? c = widget.existing;
    _name = TextEditingController(text: c?.name ?? '');
    _mobile = TextEditingController(text: c?.mobile ?? '');
    _whatsapp = TextEditingController(text: c?.whatsapp ?? '');
    _notes = TextEditingController(text: c?.notes ?? '');
    _language = c?.language ?? 'Hindi';
    _source = c?.source ?? 'Manual';
    _priority = c?.priority ?? 'Medium';
  }

  @override
  void dispose() {
    _name.dispose();
    _mobile.dispose();
    _whatsapp.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pasteNumber() async {
    final ClipboardData? data = await Clipboard.getData(Clipboard.kTextPlain);
    final String value = data?.text ?? '';
    if (value.trim().isEmpty) {
      if (mounted) showAppSnack(context, 'Clipboard empty hai.', error: true);
      return;
    }
    final String number = normalizePhone(value.split(RegExp(r'[\n,;]+')).first);
    setState(() {
      _mobile.text = number;
      _whatsapp.text = number;
    });
  }

  Future<void> _showBulkImport() async {
    final TextEditingController raw = TextEditingController();
    final String? result = await showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Import Multiple Numbers'),
        content: SizedBox(
          width: 420,
          child: TextField(
            controller: raw,
            minLines: 6,
            maxLines: 12,
            keyboardType: TextInputType.multiline,
            decoration: const InputDecoration(
              hintText: 'Har line par ek number paste karo...\n9876543210\n9988776655',
            ),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, raw.text),
            child: const Text('Import'),
          ),
        ],
      ),
    );
    raw.dispose();
    if (result == null || result.trim().isEmpty || !mounted) return;
    final int count = await AppScope.of(context).importMultipleNumbers(result);
    if (mounted) showAppSnack(context, '$count new numbers save hue.');
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _saving) return;
    setState(() => _saving = true);
    final AppController controller = AppScope.of(context);
    final String? error = widget.existing == null
        ? await controller.addCustomer(
            name: _name.text,
            mobile: _mobile.text,
            whatsapp: _whatsapp.text,
            language: _language,
            source: _source,
            notes: _notes.text,
            priority: _priority,
          )
        : await controller.updateCustomer(
            widget.existing!,
            name: _name.text,
            mobile: _mobile.text,
            whatsapp: _whatsapp.text,
            language: _language,
            source: _source,
            notes: _notes.text,
            priority: _priority,
          );
    if (!mounted) return;
    setState(() => _saving = false);
    if (error != null) {
      showAppSnack(context, error, error: true);
      return;
    }
    showAppSnack(
      context,
      widget.existing == null ? 'Customer saved.' : 'Customer updated.',
    );
    if (widget.existing != null) {
      Navigator.pop(context);
    } else {
      _name.clear();
      _mobile.clear();
      _whatsapp.clear();
      _notes.clear();
      setState(() {
        _language = 'Hindi';
        _source = 'Manual';
        _priority = 'Medium';
      });
      widget.onSaved?.call();
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final bool editing = widget.existing != null;
    return Scaffold(
      appBar: AppBar(
        leading: editing
            ? IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back),
              )
            : null,
        automaticallyImplyLeading: editing,
        title: Text(
          editing ? 'Edit Customer' : 'Add Customer',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            if (!editing)
              Row(
                children: <Widget>[
                  Expanded(
                    child: _FormShortcut(
                      icon: Icons.content_paste_rounded,
                      title: 'Paste Number',
                      subtitle: 'Clipboard se',
                      onTap: _pasteNumber,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _FormShortcut(
                      icon: Icons.playlist_add_rounded,
                      title: 'Import Multiple',
                      subtitle: 'Bulk paste',
                      onTap: _showBulkImport,
                    ),
                  ),
                ],
              ),
            if (!editing) const SizedBox(height: 18),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Customer Name',
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            const SizedBox(height: 13),
            TextFormField(
              controller: _mobile,
              keyboardType: TextInputType.phone,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]')),
              ],
              validator: (String? value) => normalizePhone(value ?? '').length < 10
                  ? 'Valid mobile number dalo'
                  : null,
              decoration: const InputDecoration(
                labelText: 'Mobile Number *',
                prefixIcon: Icon(Icons.phone_outlined),
              ),
            ),
            const SizedBox(height: 13),
            TextFormField(
              controller: _whatsapp,
              keyboardType: TextInputType.phone,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]')),
              ],
              decoration: const InputDecoration(
                labelText: 'WhatsApp Number',
                prefixIcon: Icon(Icons.chat_outlined),
                hintText: 'Blank chhodo to mobile number use hoga',
              ),
            ),
            const SizedBox(height: 13),
            Row(
              children: <Widget>[
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _language,
                    decoration: const InputDecoration(
                      labelText: 'Language',
                      prefixIcon: Icon(Icons.language),
                    ),
                    items: customerLanguages
                        .map((String value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ))
                        .toList(),
                    onChanged: (String? value) {
                      if (value != null) setState(() => _language = value);
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _priority,
                    decoration: const InputDecoration(
                      labelText: 'Priority',
                      prefixIcon: Icon(Icons.flag_outlined),
                    ),
                    items: priorities
                        .map((String value) => DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            ))
                        .toList(),
                    onChanged: (String? value) {
                      if (value != null) setState(() => _priority = value);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 13),
            DropdownButtonFormField<String>(
              value: _source,
              decoration: const InputDecoration(
                labelText: 'Customer Source',
                prefixIcon: Icon(Icons.sell_outlined),
              ),
              items: customerSources
                  .map((String value) => DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      ))
                  .toList(),
              onChanged: (String? value) {
                if (value != null) setState(() => _source = value);
              },
            ),
            const SizedBox(height: 13),
            TextFormField(
              controller: _notes,
              minLines: 4,
              maxLines: 7,
              decoration: const InputDecoration(
                labelText: 'Notes',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.notes_rounded),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 54,
              child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.save_rounded),
                label: Text(editing ? 'UPDATE CUSTOMER' : 'SAVE CUSTOMER'),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _FormShortcut extends StatelessWidget {
  const _FormShortcut({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          height: 100,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFFDDE8EA)),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: appTeal, size: 30),
              const SizedBox(height: 5),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(subtitle, style: const TextStyle(fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomerDetailPage extends StatelessWidget {
  const CustomerDetailPage({required this.customerId, super.key});
  final String customerId;

  Future<void> _changeStatus(BuildContext context, Customer customer) async {
    final String? selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (BuildContext context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.only(bottom: 16),
          children: customerStatuses
              .map((String status) => ListTile(
                    leading: CircleAvatar(
                      radius: 8,
                      backgroundColor: statusColor(status),
                    ),
                    title: Text(status),
                    trailing: customer.status == status
                        ? const Icon(Icons.check, color: appTeal)
                        : null,
                    onTap: () => Navigator.pop(context, status),
                  ))
              .toList(),
        ),
      ),
    );
    if (selected != null && context.mounted) {
      await AppScope.of(context).changeStatus(customer, selected);
    }
  }

  Future<void> _setReminder(BuildContext context, Customer customer) async {
    final DateTime? selected = await pickFollowUpDateTime(
      context,
      initial: customer.followUpAt,
    );
    if (selected == null || !context.mounted) return;
    await AppScope.of(context).setFollowUp(customer, selected);
    if (context.mounted) {
      showAppSnack(context, 'Follow-up reminder set.');
    }
  }

  Future<void> _delete(BuildContext context, Customer customer) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Delete Customer?'),
        content: const Text('Customer recycle bin me chala jayega.'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      await AppScope.of(context).deleteCustomer(customer);
      if (context.mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final Customer? customer = controller.repository.byId(customerId);
    if (customer == null || customer.deleted) {
      return Scaffold(
        appBar: AppBar(title: const Text('Customer Detail')),
        body: const _EmptyState(
          icon: Icons.person_off_outlined,
          title: 'Customer available nahi hai',
          subtitle: 'Customer delete ya sync update ho chuka hai.',
        ),
      );
    }

    final Color chipColor = statusColor(customer.status);
    final List<HistoryEntry> history = customer.history.reversed.toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Customer Detail',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: <Widget>[
          IconButton(
            tooltip: 'Edit',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => CustomerFormPage(existing: customer),
              ),
            ),
            icon: const Icon(Icons.edit_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (String value) {
              if (value == 'delete') _delete(context, customer);
            },
            itemBuilder: (_) => const <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'delete',
                child: Row(
                  children: <Widget>[
                    Icon(Icons.delete_outline, color: Colors.red),
                    SizedBox(width: 10),
                    Text('Move to Recycle Bin'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[Color(0xFF071318), Color(0xFF0A4048)],
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    CircleAvatar(
                      radius: 34,
                      backgroundColor: appTeal,
                      child: Text(
                        customer.name.isEmpty
                            ? '?'
                            : customer.name[0].toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            customer.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            displayPhone(customer.mobile),
                            style: const TextStyle(color: Colors.white70),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: chipColor,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              customer.status,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Divider(color: Colors.white24, height: 28),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _DarkInfo(
                        icon: Icons.language,
                        label: 'Language',
                        value: customer.language,
                      ),
                    ),
                    Expanded(
                      child: _DarkInfo(
                        icon: Icons.sell_outlined,
                        label: 'Source',
                        value: customer.source,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _DarkInfo(
                        icon: Icons.flag_outlined,
                        label: 'Priority',
                        value: customer.priority,
                      ),
                    ),
                    Expanded(
                      child: _DarkInfo(
                        icon: Icons.schedule,
                        label: 'Follow-Up',
                        value: customer.followUpAt == null
                            ? 'Not set'
                            : DateFormat('dd MMM, hh:mm a')
                                .format(customer.followUpAt!),
                      ),
                    ),
                  ],
                ),
                if (customer.notes.trim().isNotEmpty) ...<Widget>[
                  const SizedBox(height: 14),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Notes: ${customer.notes}',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.15,
            children: <Widget>[
              _DetailAction(
                icon: Icons.copy_rounded,
                label: 'Copy Number',
                onTap: () async {
                  await Clipboard.setData(ClipboardData(text: customer.mobile));
                  if (context.mounted) showAppSnack(context, 'Number copied.');
                },
              ),
              _DetailAction(
                icon: Icons.chat_rounded,
                label: 'WhatsApp',
                color: const Color(0xFF16A34A),
                onTap: () => openWhatsApp(context, customer),
              ),
              _DetailAction(
                icon: Icons.call_rounded,
                label: 'Call Now',
                onTap: () => openDialer(context, customer),
              ),
              _DetailAction(
                icon: Icons.sms_outlined,
                label: 'Send SMS',
                color: Colors.indigo,
                onTap: () => openSms(context, customer),
              ),
              _DetailAction(
                icon: Icons.notifications_active_outlined,
                label: 'Reminder',
                color: Colors.orange,
                onTap: () => _setReminder(context, customer),
              ),
              _DetailAction(
                icon: Icons.change_circle_outlined,
                label: 'Status',
                color: chipColor,
                onTap: () => _changeStatus(context, customer),
              ),
            ],
          ),
          if (customer.followUpAt != null) ...<Widget>[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () async {
                await controller.clearFollowUp(customer);
                if (context.mounted) {
                  showAppSnack(context, 'Follow-up completed.');
                }
              },
              icon: const Icon(Icons.task_alt),
              label: const Text('Mark Follow-Up Completed'),
            ),
          ],
          const SizedBox(height: 20),
          const Text(
            'History / Timeline',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          if (history.isEmpty)
            const Text('No history yet.')
          else
            ...history.map((HistoryEntry entry) => _TimelineTile(entry: entry)),
          const SizedBox(height: 22),
        ],
      ),
    );
  }
}

class _DarkInfo extends StatelessWidget {
  const _DarkInfo({
    required this.icon,
    required this.label,
    required this.value,
  });
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Icon(icon, size: 18, color: Colors.cyanAccent),
        const SizedBox(width: 7),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                label,
                style: const TextStyle(color: Colors.white54, fontSize: 11),
              ),
              Text(
                value,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _DetailAction extends StatelessWidget {
  const _DetailAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = appTeal,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE0EAEC)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: color, size: 27),
              const SizedBox(height: 6),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TimelineTile extends StatelessWidget {
  const _TimelineTile({required this.entry});
  final HistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE3ECEE)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const CircleAvatar(
            radius: 17,
            backgroundColor: Color(0x1A008E98),
            child: Icon(Icons.history, color: appTeal, size: 18),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  entry.title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                if (entry.detail.isNotEmpty)
                  Text(
                    entry.detail,
                    style: const TextStyle(color: Colors.black54),
                  ),
                const SizedBox(height: 3),
                Text(
                  formatDateTime(entry.at),
                  style: const TextStyle(fontSize: 11, color: Colors.black45),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FollowUpsPage extends StatefulWidget {
  const FollowUpsPage({super.key});

  @override
  State<FollowUpsPage> createState() => _FollowUpsPageState();
}

class _FollowUpsPageState extends State<FollowUpsPage>
    with AutomaticKeepAliveClientMixin {
  String _filter = 'Today';

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final AppController controller = AppScope.of(context);
    final DateTime now = DateTime.now();
    final DateTime today = DateTime(now.year, now.month, now.day);
    final DateTime tomorrow = today.add(const Duration(days: 1));

    final List<Customer> due = controller.customers.where((Customer c) {
      final DateTime? follow = c.followUpAt;
      if (follow == null) return false;
      switch (_filter) {
        case 'Overdue':
          return follow.isBefore(now);
        case 'Upcoming':
          return !follow.isBefore(tomorrow);
        default:
          return !follow.isBefore(today) && follow.isBefore(tomorrow);
      }
    }).toList()
      ..sort((Customer a, Customer b) =>
          a.followUpAt!.compareTo(b.followUpAt!));

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Follow-Ups',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(12),
            child: SegmentedButton<String>(
              segments: const <ButtonSegment<String>>[
                ButtonSegment<String>(
                  value: 'Today',
                  icon: Icon(Icons.today),
                  label: Text('Today'),
                ),
                ButtonSegment<String>(
                  value: 'Upcoming',
                  icon: Icon(Icons.upcoming_outlined),
                  label: Text('Upcoming'),
                ),
                ButtonSegment<String>(
                  value: 'Overdue',
                  icon: Icon(Icons.warning_amber_rounded),
                  label: Text('Overdue'),
                ),
              ],
              selected: <String>{_filter},
              onSelectionChanged: (Set<String> value) {
                setState(() => _filter = value.first);
              },
            ),
          ),
          Expanded(
            child: due.isEmpty
                ? _EmptyState(
                    icon: Icons.notifications_none_rounded,
                    title: '$_filter follow-up nahi hai',
                    subtitle:
                        'Customer detail me reminder set kar sakte ho.',
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 5, 12, 22),
                    itemCount: due.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (BuildContext context, int index) {
                      final Customer customer = due[index];
                      final bool overdue =
                          customer.followUpAt!.isBefore(DateTime.now());
                      return Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(18),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => CustomerDetailPage(
                                customerId: customer.id,
                              ),
                            ),
                          ),
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: overdue
                                    ? Colors.red.shade200
                                    : const Color(0xFFDDE8EA),
                              ),
                            ),
                            child: Row(
                              children: <Widget>[
                                CircleAvatar(
                                  backgroundColor: overdue
                                      ? Colors.red.withOpacity(0.12)
                                      : appTeal.withOpacity(0.12),
                                  child: Icon(
                                    overdue
                                        ? Icons.notification_important
                                        : Icons.notifications_active,
                                    color: overdue ? Colors.red : appTeal,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        customer.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                      Text(displayPhone(customer.mobile)),
                                      const SizedBox(height: 4),
                                      Text(
                                        formatDateTime(customer.followUpAt),
                                        style: TextStyle(
                                          fontWeight: FontWeight.w700,
                                          color:
                                              overdue ? Colors.red : appTeal,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                PopupMenuButton<String>(
                                  onSelected: (String value) async {
                                    if (value == 'whatsapp') {
                                      await openWhatsApp(context, customer);
                                    } else if (value == 'done') {
                                      await controller.clearFollowUp(customer);
                                    } else if (value == 'reschedule') {
                                      final DateTime? when =
                                          await pickFollowUpDateTime(
                                        context,
                                        initial: customer.followUpAt,
                                      );
                                      if (when != null && context.mounted) {
                                        await controller.setFollowUp(
                                          customer,
                                          when,
                                        );
                                      }
                                    }
                                  },
                                  itemBuilder: (_) => const <PopupMenuEntry<String>>[
                                    PopupMenuItem<String>(
                                      value: 'whatsapp',
                                      child: Text('Open WhatsApp'),
                                    ),
                                    PopupMenuItem<String>(
                                      value: 'reschedule',
                                      child: Text('Reschedule'),
                                    ),
                                    PopupMenuItem<String>(
                                      value: 'done',
                                      child: Text('Mark Completed'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _editTemplate(BuildContext context) async {
    final AppController controller = AppScope.of(context);
    final TextEditingController text =
        TextEditingController(text: controller.messageTemplate);
    final String? value = await showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('WhatsApp Message Template'),
        content: SizedBox(
          width: 430,
          child: TextField(
            controller: text,
            minLines: 5,
            maxLines: 10,
            decoration: const InputDecoration(
              helperText: '{name} aur {number} auto replace honge.',
            ),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, text.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    text.dispose();
    if (value != null && value.trim().isNotEmpty && context.mounted) {
      await controller.setMessageTemplate(value);
      if (context.mounted) showAppSnack(context, 'Template saved.');
    }
  }

  Future<void> _restoreBackup(BuildContext context) async {
    final ClipboardData? data = await Clipboard.getData(Clipboard.kTextPlain);
    final String raw = data?.text ?? '';
    if (raw.trim().isEmpty) {
      if (context.mounted) {
        showAppSnack(context, 'Clipboard empty hai.', error: true);
      }
      return;
    }
    try {
      await AppScope.of(context).importBackup(raw);
      if (context.mounted) showAppSnack(context, 'Backup restored.');
    } catch (_) {
      if (context.mounted) {
        showAppSnack(context, 'Backup JSON invalid hai.', error: true);
      }
    }
  }

  Future<void> _showRecycleBin(BuildContext context) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const RecycleBinPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: appDark,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    ClipOval(
                      child: Image.asset(
                        'assets/branding/app_icon_safe.png',
                        width: 68,
                        height: 68,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 13),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Customer Manager 99',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            'Allrounder99 & Rajahuli99',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: controller.cloudConnected
                        ? const Color(0x2234D399)
                        : const Color(0x22F59E0B),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: <Widget>[
                      Icon(
                        controller.cloudConnected
                            ? Icons.cloud_done
                            : Icons.cloud_off,
                        color: controller.cloudConnected
                            ? Colors.greenAccent
                            : Colors.orangeAccent,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          controller.cloudConnected
                              ? 'Cloud Sync Connected — same data dusre phone me show hoga.'
                              : 'Local Mode — Firebase build config add karne ke baad cross-phone sync active hoga.',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SettingsTile(
            icon: Icons.message_outlined,
            title: 'WhatsApp Message Template',
            subtitle: 'Customer chat ke liye default message edit karo',
            onTap: () => _editTemplate(context),
          ),
          _SettingsTile(
            icon: Icons.copy_all_rounded,
            title: 'Copy Full Backup',
            subtitle: 'Saara customer data JSON clipboard me copy hoga',
            onTap: () async {
              await Clipboard.setData(
                ClipboardData(text: controller.exportBackup()),
              );
              if (context.mounted) showAppSnack(context, 'Backup copied.');
            },
          ),
          _SettingsTile(
            icon: Icons.restore_page_rounded,
            title: 'Restore Backup from Clipboard',
            subtitle: 'Copied JSON se customer data restore karo',
            onTap: () => _restoreBackup(context),
          ),
          _SettingsTile(
            icon: Icons.delete_sweep_outlined,
            title: 'Recycle Bin (${controller.deletedCustomers.length})',
            subtitle: 'Deleted customers restore ya permanently delete karo',
            onTap: () => _showRecycleBin(context),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(
                child: _BrandMiniCard(
                  image: 'assets/branding/allrounder99.png',
                  title: 'Allrounder99',
                  accent: Colors.cyan,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _BrandMiniCard(
                  image: 'assets/branding/rajahuli99.jpg',
                  title: 'Rajahuli99',
                  accent: Colors.orange,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: controller.logout,
            icon: const Icon(Icons.logout),
            label: const Text('LOGOUT'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.red.shade700,
              minimumSize: const Size.fromHeight(52),
            ),
          ),
          const SizedBox(height: 22),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFE0EAEC)),
            ),
            child: Row(
              children: <Widget>[
                CircleAvatar(
                  backgroundColor: appTeal.withOpacity(0.12),
                  child: Icon(icon, color: appTeal),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        title,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class RecycleBinPage extends StatelessWidget {
  const RecycleBinPage({super.key});

  @override
  Widget build(BuildContext context) {
    final AppController controller = AppScope.of(context);
    final List<Customer> customers = controller.deletedCustomers;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Recycle Bin (${customers.length})',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: customers.isEmpty
          ? const _EmptyState(
              icon: Icons.delete_outline,
              title: 'Recycle bin empty hai',
              subtitle: 'Deleted customers yahan show honge.',
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: customers.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (BuildContext context, int index) {
                final Customer customer = customers[index];
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFE1EAEC)),
                  ),
                  child: Row(
                    children: <Widget>[
                      const CircleAvatar(
                        child: Icon(Icons.person_outline),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              customer.name,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w900),
                            ),
                            Text(displayPhone(customer.mobile)),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Restore',
                        onPressed: () => controller.restoreCustomer(customer),
                        icon: const Icon(Icons.restore, color: appTeal),
                      ),
                      IconButton(
                        tooltip: 'Delete permanently',
                        onPressed: () async {
                          final bool? confirm = await showDialog<bool>(
                            context: context,
                            builder: (BuildContext context) => AlertDialog(
                              title: const Text('Permanently Delete?'),
                              content: const Text(
                                'Is action ko undo nahi kar sakte.',
                              ),
                              actions: <Widget>[
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text('Cancel'),
                                ),
                                FilledButton(
                                  onPressed: () =>
                                      Navigator.pop(context, true),
                                  child: const Text('Delete'),
                                ),
                              ],
                            ),
                          );
                          if (confirm == true && context.mounted) {
                            await controller.permanentlyDelete(customer);
                          }
                        },
                        icon: const Icon(Icons.delete_forever, color: Colors.red),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
