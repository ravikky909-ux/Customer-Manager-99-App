import 'dart:convert';

class HistoryEntry {
  const HistoryEntry({
    required this.title,
    required this.detail,
    required this.at,
  });

  final String title;
  final String detail;
  final DateTime at;

  Map<String, dynamic> toMap() => <String, dynamic>{
        'title': title,
        'detail': detail,
        'at': at.toUtc().toIso8601String(),
      };

  factory HistoryEntry.fromMap(Map<String, dynamic> map) => HistoryEntry(
        title: (map['title'] ?? '').toString(),
        detail: (map['detail'] ?? '').toString(),
        at: DateTime.tryParse((map['at'] ?? '').toString())?.toLocal() ??
            DateTime.now(),
      );
}

class Customer {
  const Customer({
    required this.id,
    required this.name,
    required this.mobile,
    required this.whatsapp,
    required this.language,
    required this.source,
    required this.notes,
    required this.status,
    required this.priority,
    required this.createdAt,
    required this.updatedAt,
    required this.followUpAt,
    required this.deleted,
    required this.history,
  });

  final String id;
  final String name;
  final String mobile;
  final String whatsapp;
  final String language;
  final String source;
  final String notes;
  final String status;
  final String priority;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? followUpAt;
  final bool deleted;
  final List<HistoryEntry> history;

  Customer copyWith({
    String? name,
    String? mobile,
    String? whatsapp,
    String? language,
    String? source,
    String? notes,
    String? status,
    String? priority,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? followUpAt,
    bool clearFollowUp = false,
    bool? deleted,
    List<HistoryEntry>? history,
  }) {
    return Customer(
      id: id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      whatsapp: whatsapp ?? this.whatsapp,
      language: language ?? this.language,
      source: source ?? this.source,
      notes: notes ?? this.notes,
      status: status ?? this.status,
      priority: priority ?? this.priority,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      followUpAt: clearFollowUp ? null : (followUpAt ?? this.followUpAt),
      deleted: deleted ?? this.deleted,
      history: history ?? this.history,
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
        'id': id,
        'name': name,
        'mobile': mobile,
        'whatsapp': whatsapp,
        'language': language,
        'source': source,
        'notes': notes,
        'status': status,
        'priority': priority,
        'createdAt': createdAt.toUtc().toIso8601String(),
        'updatedAt': updatedAt.toUtc().toIso8601String(),
        'followUpAt': followUpAt?.toUtc().toIso8601String(),
        'deleted': deleted,
        'history': history.map((HistoryEntry e) => e.toMap()).toList(),
      };

  factory Customer.fromMap(Map<String, dynamic> map) {
    DateTime parseDate(dynamic value, {DateTime? fallback}) {
      if (value is DateTime) return value.toLocal();
      final DateTime? parsed = DateTime.tryParse((value ?? '').toString());
      return parsed?.toLocal() ?? fallback ?? DateTime.now();
    }

    final dynamic rawHistory = map['history'];
    return Customer(
      id: (map['id'] ?? '').toString(),
      name: (map['name'] ?? 'Unknown Customer').toString(),
      mobile: (map['mobile'] ?? '').toString(),
      whatsapp: (map['whatsapp'] ?? map['mobile'] ?? '').toString(),
      language: (map['language'] ?? 'Hindi').toString(),
      source: (map['source'] ?? 'Manual').toString(),
      notes: (map['notes'] ?? '').toString(),
      status: (map['status'] ?? 'Not Messaged').toString(),
      priority: (map['priority'] ?? 'Medium').toString(),
      createdAt: parseDate(map['createdAt']),
      updatedAt: parseDate(map['updatedAt']),
      followUpAt: map['followUpAt'] == null
          ? null
          : parseDate(map['followUpAt']),
      deleted: map['deleted'] == true,
      history: rawHistory is List
          ? rawHistory
              .whereType<Map>()
              .map((Map e) => HistoryEntry.fromMap(
                    Map<String, dynamic>.from(e),
                  ))
              .toList()
          : <HistoryEntry>[],
    );
  }

  static String encodeList(List<Customer> customers) => jsonEncode(
        customers.map((Customer c) => c.toMap()).toList(),
      );

  static List<Customer> decodeList(String raw) {
    final dynamic decoded = jsonDecode(raw);
    if (decoded is! List) return <Customer>[];
    return decoded
        .whereType<Map>()
        .map((Map e) => Customer.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }
}

const List<String> customerStatuses = <String>[
  'Not Messaged',
  'Messaged',
  'Reply Received',
  'Interested',
  'Follow-Up',
  'Converted',
  'Not Interested',
  'Wrong Number',
  'Do Not Contact',
];

const List<String> customerLanguages = <String>[
  'Hindi',
  'Kannada',
  'English',
];

const List<String> customerSources = <String>[
  'Manual',
  'WhatsApp',
  'Telegram',
  'Website',
  'Instagram Ad',
  'Facebook Ad',
  'Calling',
  'Reference',
];

const List<String> priorities = <String>['High', 'Medium', 'Low'];
