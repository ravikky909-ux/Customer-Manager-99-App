import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import 'models.dart';

class FirebaseRuntimeConfig {
  static const String apiKey = String.fromEnvironment('FIREBASE_API_KEY');
  static const String appId = String.fromEnvironment('FIREBASE_APP_ID');
  static const String messagingSenderId =
      String.fromEnvironment('FIREBASE_MESSAGING_SENDER_ID');
  static const String projectId = String.fromEnvironment('FIREBASE_PROJECT_ID');
  static const String storageBucket =
      String.fromEnvironment('FIREBASE_STORAGE_BUCKET');

  static bool get isConfigured =>
      apiKey.trim().isNotEmpty &&
      appId.trim().isNotEmpty &&
      messagingSenderId.trim().isNotEmpty &&
      projectId.trim().isNotEmpty;

  static FirebaseOptions get options => FirebaseOptions(
        apiKey: apiKey,
        appId: appId,
        messagingSenderId: messagingSenderId,
        projectId: projectId,
        storageBucket: storageBucket.trim().isEmpty ? null : storageBucket,
      );
}

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _ready = false;

  Future<void> initialize() async {
    try {
      tz.initializeTimeZones();
      if (!kIsWeb && !Platform.isWindows) {
        final TimezoneInfo info = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(info.identifier));
      }

      const AndroidInitializationSettings android =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      const InitializationSettings settings =
          InitializationSettings(android: android);
      await _plugin.initialize(settings: settings);

      if (!kIsWeb && Platform.isAndroid) {
        await _plugin
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>()
            ?.requestNotificationsPermission();
      }
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  Future<void> scheduleCustomerFollowUp(Customer customer) async {
    if (!_ready || customer.followUpAt == null) return;
    final DateTime when = customer.followUpAt!;
    if (!when.isAfter(DateTime.now())) return;

    const AndroidNotificationDetails android = AndroidNotificationDetails(
      'customer_followups',
      'Customer Follow-Ups',
      channelDescription: 'Customer follow-up reminders',
      importance: Importance.high,
      priority: Priority.high,
    );
    await _plugin.zonedSchedule(
      id: customer.id.hashCode & 0x7fffffff,
      title: 'Customer follow-up',
      body: '${customer.name} (${customer.mobile}) ko follow-up karna hai.',
      scheduledDate: tz.TZDateTime.from(when, tz.local),
      notificationDetails:
          const NotificationDetails(android: android),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: customer.id,
    );
  }

  Future<void> cancelCustomerFollowUp(String customerId) async {
    if (!_ready) return;
    await _plugin.cancel(id: customerId.hashCode & 0x7fffffff);
  }
}

class CustomerRepository extends ChangeNotifier {
  CustomerRepository(this._prefs);

  static const String _storageKey = 'customer_manager_99_customers_v2';
  final SharedPreferences _prefs;
  final List<Customer> _customers = <Customer>[];
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _cloudSub;
  CollectionReference<Map<String, dynamic>>? _cloudCollection;
  bool _cloudConnected = false;
  String? _cloudError;

  List<Customer> get all => List<Customer>.unmodifiable(_customers);
  List<Customer> get active => _customers
      .where((Customer c) => !c.deleted)
      .toList()
    ..sort((Customer a, Customer b) => b.updatedAt.compareTo(a.updatedAt));
  List<Customer> get deleted => _customers
      .where((Customer c) => c.deleted)
      .toList()
    ..sort((Customer a, Customer b) => b.updatedAt.compareTo(a.updatedAt));
  bool get cloudConnected => _cloudConnected;
  String? get cloudError => _cloudError;

  Future<void> initializeLocal() async {
    final String? raw = _prefs.getString(_storageKey);
    if (raw != null && raw.trim().isNotEmpty) {
      try {
        _customers
          ..clear()
          ..addAll(Customer.decodeList(raw));
      } catch (_) {
        _customers.clear();
      }
    }
    notifyListeners();
  }

  Future<void> connectCloud({required String password}) async {
    if (!FirebaseRuntimeConfig.isConfigured) {
      _cloudConnected = false;
      _cloudError = 'Firebase config not added';
      notifyListeners();
      return;
    }

    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(options: FirebaseRuntimeConfig.options);
      }
      const String email = 'allrounder99@customer-manager-99.app';
      UserCredential credential;
      try {
        credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: password,
        );
      } on FirebaseAuthException catch (error) {
        if (error.code == 'user-not-found' ||
            error.code == 'invalid-credential') {
          credential = await FirebaseAuth.instance
              .createUserWithEmailAndPassword(email: email, password: password);
        } else {
          rethrow;
        }
      }

      final String uid = credential.user!.uid;
      _cloudCollection = FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .collection('customers');

      final QuerySnapshot<Map<String, dynamic>> initial =
          await _cloudCollection!.get();
      final Map<String, Customer> merged = <String, Customer>{
        for (final Customer customer in _customers) customer.id: customer,
      };
      for (final QueryDocumentSnapshot<Map<String, dynamic>> doc
          in initial.docs) {
        final Customer cloudCustomer = Customer.fromMap(<String, dynamic>{
          ...doc.data(),
          'id': doc.id,
        });
        final Customer? localCustomer = merged[cloudCustomer.id];
        if (localCustomer == null ||
            cloudCustomer.updatedAt.isAfter(localCustomer.updatedAt)) {
          merged[cloudCustomer.id] = cloudCustomer;
        }
      }
      _customers
        ..clear()
        ..addAll(merged.values);
      await _saveLocal();
      if (merged.isNotEmpty) {
        final WriteBatch batch = FirebaseFirestore.instance.batch();
        for (final Customer customer in merged.values) {
          batch.set(_cloudCollection!.doc(customer.id), customer.toMap());
        }
        await batch.commit();
      }

      await _cloudSub?.cancel();
      _cloudSub = _cloudCollection!.snapshots().listen(
        (QuerySnapshot<Map<String, dynamic>> snapshot) async {
          _customers
            ..clear()
            ..addAll(snapshot.docs.map(
              (QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
                  Customer.fromMap(<String, dynamic>{
                ...doc.data(),
                'id': doc.id,
              }),
            ));
          await _saveLocal();
          notifyListeners();
        },
        onError: (Object error) {
          _cloudConnected = false;
          _cloudError = error.toString();
          notifyListeners();
        },
      );

      _cloudConnected = true;
      _cloudError = null;
      notifyListeners();
    } catch (error) {
      _cloudConnected = false;
      _cloudError = error.toString();
      notifyListeners();
    }
  }

  Customer? byId(String id) {
    try {
      return _customers.firstWhere((Customer c) => c.id == id);
    } catch (_) {
      return null;
    }
  }

  bool hasDuplicateNumber(String number, {String? exceptId}) {
    final String normalized = normalizePhone(number);
    if (normalized.isEmpty) return false;
    return _customers.any((Customer c) =>
        !c.deleted &&
        c.id != exceptId &&
        normalizePhone(c.mobile) == normalized);
  }

  Future<void> upsert(Customer customer) async {
    final int index = _customers.indexWhere((Customer c) => c.id == customer.id);
    if (index == -1) {
      _customers.add(customer);
    } else {
      _customers[index] = customer;
    }
    await _saveLocal();
    notifyListeners();
    await _cloudCollection?.doc(customer.id).set(customer.toMap());
  }

  Future<void> moveToRecycleBin(Customer customer) async {
    final Customer updated = customer.copyWith(
      deleted: true,
      updatedAt: DateTime.now(),
      history: <HistoryEntry>[
        ...customer.history,
        HistoryEntry(
          title: 'Moved to Recycle Bin',
          detail: 'Customer was deleted',
          at: DateTime.now(),
        ),
      ],
    );
    await upsert(updated);
  }

  Future<void> restore(Customer customer) async {
    final Customer updated = customer.copyWith(
      deleted: false,
      updatedAt: DateTime.now(),
      history: <HistoryEntry>[
        ...customer.history,
        HistoryEntry(
          title: 'Customer Restored',
          detail: 'Restored from recycle bin',
          at: DateTime.now(),
        ),
      ],
    );
    await upsert(updated);
  }

  Future<void> permanentlyDelete(Customer customer) async {
    _customers.removeWhere((Customer c) => c.id == customer.id);
    await _saveLocal();
    notifyListeners();
    await _cloudCollection?.doc(customer.id).delete();
  }

  Future<void> replaceAll(List<Customer> customers) async {
    _customers
      ..clear()
      ..addAll(customers);
    await _saveLocal();
    notifyListeners();
    if (_cloudCollection != null) {
      final QuerySnapshot<Map<String, dynamic>> existing =
          await _cloudCollection!.get();
      final WriteBatch batch = FirebaseFirestore.instance.batch();
      for (final QueryDocumentSnapshot<Map<String, dynamic>> doc
          in existing.docs) {
        batch.delete(doc.reference);
      }
      for (final Customer customer in customers) {
        batch.set(_cloudCollection!.doc(customer.id), customer.toMap());
      }
      await batch.commit();
    }
  }

  String exportJson() => const JsonEncoder.withIndent('  ').convert(
        _customers.map((Customer c) => c.toMap()).toList(),
      );

  Future<void> importJson(String raw) async {
    final dynamic data = jsonDecode(raw);
    if (data is! List) {
      throw const FormatException('Backup format invalid');
    }
    final List<Customer> imported = data
        .whereType<Map>()
        .map((Map e) => Customer.fromMap(Map<String, dynamic>.from(e)))
        .toList();
    await replaceAll(imported);
  }

  Future<void> _saveLocal() async {
    await _prefs.setString(_storageKey, Customer.encodeList(_customers));
  }

  Future<void> disposeCloud() async {
    await _cloudSub?.cancel();
    _cloudSub = null;
    _cloudCollection = null;
    _cloudConnected = false;
    if (Firebase.apps.isNotEmpty) {
      await FirebaseAuth.instance.signOut();
    }
  }

  @override
  void dispose() {
    _cloudSub?.cancel();
    super.dispose();
  }
}

String normalizePhone(String value) {
  String digits = value.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.startsWith('00')) digits = digits.substring(2);
  if (digits.length == 11 && digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  if (digits.length == 10) digits = '91$digits';
  if (digits.length == 12 && digits.startsWith('91')) return digits;
  return digits;
}
