import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_controller.dart';
import 'app_scope.dart';
import 'screens.dart';
import 'services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  final NotificationService notifications = NotificationService();
  await notifications.initialize();
  final CustomerRepository repository = CustomerRepository(prefs);
  await repository.initializeLocal();
  final AppController controller = AppController(
    repository: repository,
    notifications: notifications,
    prefs: prefs,
  );
  runApp(CustomerManagerApp(controller: controller));
}

class CustomerManagerApp extends StatefulWidget {
  const CustomerManagerApp({required this.controller, super.key});
  final AppController controller;

  @override
  State<CustomerManagerApp> createState() => _CustomerManagerAppState();
}

class _CustomerManagerAppState extends State<CustomerManagerApp> {
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 3000), () {
      if (mounted) setState(() => _showSplash = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    const Color teal = Color(0xFF008E98);
    const Color dark = Color(0xFF071318);
    return AppScope(
      controller: widget.controller,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Customer Manager 99',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          colorScheme: ColorScheme.fromSeed(
            seedColor: teal,
            primary: teal,
            secondary: const Color(0xFFFFB625),
            surface: const Color(0xFFF7FAFB),
          ),
          scaffoldBackgroundColor: const Color(0xFFF4F8F9),
          appBarTheme: const AppBarTheme(
            backgroundColor: teal,
            foregroundColor: Colors.white,
            centerTitle: false,
            elevation: 0,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFDCE7E9)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: teal, width: 1.5),
            ),
          ),
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: dark,
            indicatorColor: teal.withOpacity(0.22),
            labelTextStyle: WidgetStateProperty.resolveWith<TextStyle>((
              Set<WidgetState> states,
            ) {
              return TextStyle(
                color: states.contains(WidgetState.selected)
                    ? Colors.cyanAccent
                    : Colors.white70,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              );
            }),
            iconTheme: WidgetStateProperty.resolveWith<IconThemeData>((
              Set<WidgetState> states,
            ) {
              return IconThemeData(
                color: states.contains(WidgetState.selected)
                    ? Colors.cyanAccent
                    : Colors.white70,
              );
            }),
          ),
          cardTheme: const CardThemeData(
            elevation: 0,
            margin: EdgeInsets.zero,
            color: Colors.white,
          ),
        ),
        home: AnimatedBuilder(
          animation: widget.controller,
          builder: (BuildContext context, Widget? child) {
            if (_showSplash) return const SplashScreen();
            return widget.controller.loggedIn
                ? const MainShellScreen()
                : const LoginScreen();
          },
        ),
      ),
    );
  }
}
