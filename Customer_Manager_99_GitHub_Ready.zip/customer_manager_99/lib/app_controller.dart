import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import 'models.dart';
import 'services.dart';

class LoginResult {
  const LoginResult({required this.success, required this.message});
  final bool success;
  final String message;
}

class AppController extends ChangeNotifier {
  AppController({
    required this.repository,
    required this.notifications,
    required SharedPreferences prefs,
  }) : _prefs = prefs {
    repository.addListener(_repositoryChanged);
    _messageTemplate = _prefs.getString('message_template') ??
        'Hello {name}, namaste! Hamari support team aapki help ke liye available hai.';
  }

  final CustomerRepository repository;
  final NotificationService notifications;
  final SharedPreferences _prefs;
  final Uuid _uuid = const Uuid();

  bool _loggedIn = false;
  bool _loginBusy = false;
  int _pageIndex = 0;
  String _customerFilter = 'All';
  late String _messageTemplate;

  bool get loggedIn => _loggedIn;
  bool get loginBusy => _loginBusy;
  int get pageIndex => _pageIndex;
  String get customerFilter => _customerFilter;
  String get messageTemplate => _messageTemplate;
  bool get cloudConnected => repository.cloudConnected;
  String? get cloudError => repository.cloudError;
  List<Customer> get customers => repository.active;
  List<Customer> get deletedCustomers => repository.deleted;

  Future<LoginResult> login(String id, String password) async {
    if (_loginBusy) {
      return const LoginResult(success: false, message: 'Please wait...');
    }
    if (id.trim() != 'Allrounder99' || password != 'Kris@3060') {
      return const LoginResult(
        success: false,
        message: 'ID ya password galat hai.',
      );
    }

    _loginBusy = true;
    notifyListeners();
    await repository.connectCloud(password: password);
    _loggedIn = true;
    _loginBusy = false;
    notifyListeners();

    if (repository.cloudConnected) {
      return const LoginResult(
        success: true,
        message: 'Login successful. Cloud sync connected.',
      );
    }
    return LoginResult(
      success: true,
      message: repository.cloudError == 'Firebase config not added'
          ? 'Login successful. Cloud config add hone tak app local mode me chalega.'
          : 'Login successful. Cloud connect nahi hua, local data safe hai.',
    );
  }

  Future<void> logout() async {
    await repository.disposeCloud();
    _loggedIn = false;
    _pageIndex = 0;
    notifyListeners();
  }

  void setPage(int value) {
    if (_pageIndex == value) return;
    _pageIndex = value;
    notifyListeners();
  }

  void openCustomers({String filter = 'All'}) {
    _customerFilter = filter;
    _pageIndex = 1;
    notifyListeners();
  }

  void setCustomerFilter(String value) {
    if (_customerFilter == value) return;
    _customerFilter = value;
    notifyListeners();
  }

  Future<String?> addCustomer({
    required String name,
    required String mobile,
    required String whatsapp,
    required String language,
    required String source,
    required String notes,
    required String priority,
  }) async {
    final String normalizedMobile = normalizePhone(mobile);
    if (normalizedMobile.length < 10) return 'Valid mobile number dalo.';
    if (repository.hasDuplicateNumber(normalizedMobile)) {
      return 'Ye number pehle se saved hai.';
    }
    final DateTime now = DateTime.now();
    final Customer customer = Customer(
      id: _uuid.v4(),
      name: name.trim().isEmpty ? 'Unknown Customer' : name.trim(),
      mobile: normalizedMobile,
      whatsapp: normalizePhone(whatsapp.trim().isEmpty ? mobile : whatsapp),
      language: language,
      source: source,
      notes: notes.trim(),
      status: 'Not Messaged',
      priority: priority,
      createdAt: now,
      updatedAt: now,
      followUpAt: null,
      deleted: false,
      history: <HistoryEntry>[
        HistoryEntry(
          title: 'Customer Added',
          detail: 'Customer number saved',
          at: now,
        ),
      ],
    );
    await repository.upsert(customer);
    return null;
  }

  Future<int> importMultipleNumbers(String raw) async {
    final List<String> lines = raw
        .split(RegExp(r'[\n,;]+'))
        .map((String e) => e.trim())
        .where((String e) => e.isNotEmpty)
        .toList();
    int added = 0;
    for (final String line in lines) {
      final String number = normalizePhone(line);
      if (number.length < 10 || repository.hasDuplicateNumber(number)) continue;
      final String? error = await addCustomer(
        name: 'Customer ${customers.length + 1}',
        mobile: number,
        whatsapp: number,
        language: 'Hindi',
        source: 'Manual',
        notes: 'Bulk imported',
        priority: 'Medium',
      );
      if (error == null) added++;
    }
    return added;
  }

  Future<String?> updateCustomer(Customer original, {
    required String name,
    required String mobile,
    required String whatsapp,
    required String language,
    required String source,
    required String notes,
    required String priority,
  }) async {
    final String normalized = normalizePhone(mobile);
    if (normalized.length < 10) return 'Valid mobile number dalo.';
    if (repository.hasDuplicateNumber(normalized, exceptId: original.id)) {
      return 'Ye number kisi aur customer me saved hai.';
    }
    final DateTime now = DateTime.now();
    final Customer updated = original.copyWith(
      name: name.trim().isEmpty ? 'Unknown Customer' : name.trim(),
      mobile: normalized,
      whatsapp: normalizePhone(whatsapp.trim().isEmpty ? mobile : whatsapp),
      language: language,
      source: source,
      notes: notes.trim(),
      priority: priority,
      updatedAt: now,
      history: <HistoryEntry>[
        ...original.history,
        HistoryEntry(
          title: 'Customer Updated',
          detail: 'Profile details updated',
          at: now,
        ),
      ],
    );
    await repository.upsert(updated);
    return null;
  }

  Future<void> markWhatsAppOpened(Customer customer) async {
    final DateTime now = DateTime.now();
    final Customer updated = customer.copyWith(
      status: customer.status == 'Not Messaged' ? 'Messaged' : customer.status,
      updatedAt: now,
      history: <HistoryEntry>[
        ...customer.history,
        HistoryEntry(
          title: 'WhatsApp Opened',
          detail: 'WhatsApp chat opened from app',
          at: now,
        ),
      ],
    );
    await repository.upsert(updated);
  }

  Future<void> changeStatus(Customer customer, String status) async {
    final DateTime now = DateTime.now();
    final Customer updated = customer.copyWith(
      status: status,
      updatedAt: now,
      history: <HistoryEntry>[
        ...customer.history,
        HistoryEntry(
          title: 'Status Changed',
          detail: status,
          at: now,
        ),
      ],
    );
    await repository.upsert(updated);
  }

  Future<void> setFollowUp(Customer customer, DateTime when) async {
    final DateTime now = DateTime.now();
    final Customer updated = customer.copyWith(
      status: customer.status == 'Converted' ? customer.status : 'Follow-Up',
      followUpAt: when,
      updatedAt: now,
      history: <HistoryEntry>[
        ...customer.history,
        HistoryEntry(
          title: 'Follow-Up Set',
          detail: when.toLocal().toString(),
          at: now,
        ),
      ],
    );
    await repository.upsert(updated);
    await notifications.scheduleCustomerFollowUp(updated);
  }

  Future<void> clearFollowUp(Customer customer) async {
    final DateTime now = DateTime.now();
    final Customer updated = customer.copyWith(
      clearFollowUp: true,
      updatedAt: now,
      history: <HistoryEntry>[
        ...customer.history,
        HistoryEntry(
          title: 'Follow-Up Completed',
          detail: 'Reminder cleared',
          at: now,
        ),
      ],
    );
    await repository.upsert(updated);
    await notifications.cancelCustomerFollowUp(customer.id);
  }

  Future<void> deleteCustomer(Customer customer) async {
    await notifications.cancelCustomerFollowUp(customer.id);
    await repository.moveToRecycleBin(customer);
  }

  Future<void> restoreCustomer(Customer customer) => repository.restore(customer);

  Future<void> permanentlyDelete(Customer customer) =>
      repository.permanentlyDelete(customer);

  Future<void> importBackup(String raw) => repository.importJson(raw);
  String exportBackup() => repository.exportJson();

  Future<void> setMessageTemplate(String value) async {
    _messageTemplate = value.trim();
    await _prefs.setString('message_template', _messageTemplate);
    notifyListeners();
  }

  String personalizedMessage(Customer customer) => _messageTemplate
      .replaceAll('{name}', customer.name)
      .replaceAll('{number}', customer.mobile);

  void _repositoryChanged() => notifyListeners();

  @override
  void dispose() {
    repository.removeListener(_repositoryChanged);
    super.dispose();
  }
}
