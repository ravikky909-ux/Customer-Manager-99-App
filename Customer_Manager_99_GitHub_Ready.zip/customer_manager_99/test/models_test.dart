import 'package:customer_manager_99/models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('customer JSON round trip keeps core fields', () {
    final DateTime now = DateTime(2026, 7, 20, 10, 30);
    final Customer customer = Customer(
      id: '1',
      name: 'Test Customer',
      mobile: '919876543210',
      whatsapp: '919876543210',
      language: 'Hindi',
      source: 'Manual',
      notes: 'Test',
      status: 'Not Messaged',
      priority: 'Medium',
      createdAt: now,
      updatedAt: now,
      followUpAt: null,
      deleted: false,
      history: <HistoryEntry>[],
    );

    final List<Customer> decoded =
        Customer.decodeList(Customer.encodeList(<Customer>[customer]));
    expect(decoded.single.name, 'Test Customer');
    expect(decoded.single.mobile, '919876543210');
  });
}
